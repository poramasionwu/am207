from modules.residual_block import sequence_residual_block as ResidualBlocks
from modules.mlp_block import sequence_mlp_block as MLPBlocks
from modules.memory_layer import MemoryLayer
